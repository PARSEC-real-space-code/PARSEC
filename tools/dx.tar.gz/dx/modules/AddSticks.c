/*
 * Automatically generated on "/tmp/AddSticks.mb" by DX Module Builder
 */

#include "dx/dx.h"
#include <math.h>

static Error traverse(Object *, Object *);
static Error doLeaf(Object *, Object *);

/*
 * Declare the interface routine.
 */
int
AddSticks_worker(
    int, int, float *,
    int, float *,
    int, float *,
    int, int *,
    int, float *,
    int, float *);

Error
m_AddSticks(Object *in, Object *out)
{
  int i;

  /*
   * Initialize all outputs to NULL
   */
  for (i = 0; i < 2; i++)
    out[i] = NULL;

  /*
   * Error checks: required inputs are verified.
   */

  /* Parameter "balls" is required. */
  if (in[0] == NULL)
  {
    DXSetError(ERROR_MISSING_DATA, "\"balls\" must be specified");
    return ERROR;
  }


  /*
   * Since output "balls_with_connections" is structure Field/Group, it initially
   * is a copy of input "balls".
   */
  out[0] = DXCopy(in[0], COPY_STRUCTURE);
  if (! out[0])
    goto error;

  /*
   * If in[0] was an array, then no copy is actually made - Copy 
   * returns a pointer to the input object.  Since this can't be written to
   * we postpone explicitly copying it until the leaf level, when we'll need
   * to be creating writable arrays anyway.
   */
  if (out[0] == in[0])
    out[0] = NULL;

  /*
   * Since output "sticks" is structure Field/Group, it initially
   * is a copy of input "balls".
   */
  out[1] = DXCopy(in[0], COPY_STRUCTURE);
  if (! out[1])
    goto error;

  /*
   * If in[0] was an array, then no copy is actually made - Copy 
   * returns a pointer to the input object.  Since this can't be written to
   * we postpone explicitly copying it until the leaf level, when we'll need
   * to be creating writable arrays anyway.
   */
  if (out[1] == in[0])
    out[1] = NULL;

  /*
   * Call the hierarchical object traversal routine
   */
  if (!traverse(in, out))
    goto error;

  return OK;

error:
  /*
   * On error, any successfully-created outputs are deleted.
   */
  for (i = 0; i < 2; i++)
  {
    if (in[i] != out[i])
      DXDelete(out[i]);
    out[i] = NULL;
  }
  return ERROR;
}


static Error
traverse(Object *in, Object *out)
{
  switch(DXGetObjectClass(in[0]))
  {
    case CLASS_FIELD:
    case CLASS_ARRAY:
    case CLASS_STRING:
      /*
       * If we have made it to the leaf level, call the leaf handler.
       */
      if (! doLeaf(in, out))
  	     return ERROR;

      return OK;

    case CLASS_GROUP:
    {
      int   i, j;
      int   memknt;
      Class groupClass  = DXGetGroupClass((Group)in[0]);

      DXGetMemberCount((Group)in[0], &memknt);


       /*
        * Create new in and out lists for each child
        * of the first input. 
        */
        for (i = 0; i < memknt; i++)
        {
          Object new_in[3], new_out[2];

         /*
          * For all inputs that are Values, pass them to 
          * child object list.  For all that are Field/Group, get 
          * the appropriate decendent and place it into the
          * child input object list.
          */

          /* input "balls" is Field/Group */
          if (in[0])
            new_in[0] = DXGetEnumeratedMember((Group)in[0], i, NULL);
          else
            new_in[0] = NULL;

          /* input "max_bond_length" is Value */
          new_in[1] = in[1];

          /* input "max_number_bonds" is Value */
          new_in[2] = in[2];

         /*
          * For all outputs that are Values, pass them to 
          * child object list.  For all that are Field/Group,  get
          * the appropriate decendent and place it into the
          * child output object list.  Note that none should
          * be NULL (unlike inputs, which can default).
          */

          /* output "balls_with_connections" is Field/Group */
          new_out[0] = DXGetEnumeratedMember((Group)out[0], i, NULL);

          /* output "sticks" is Field/Group */
          new_out[1] = DXGetEnumeratedMember((Group)out[1], i, NULL);

          if (! traverse(new_in, new_out))
            return ERROR;

         /*
          * Now for each output that is not a Value, replace
          * the updated child into the object in the parent.
          */

          /* output "balls_with_connections" is Field/Group */
          DXSetEnumeratedMember((Group)out[0], i, new_out[0]);

          /* output "sticks" is Field/Group */
          DXSetEnumeratedMember((Group)out[1], i, new_out[1]);

        }
      return OK;
    }

    case CLASS_XFORM:
    {
      int    i, j;
      Object new_in[3], new_out[2];


      /*
       * Create new in and out lists for the decendent of the
       * first input.  For inputs and outputs that are Values
       * copy them into the new in and out lists.  Otherwise
       * get the corresponding decendents.
       */

      /* input "balls" is Field/Group */
      if (in[0])
        DXGetXformInfo((Xform)in[0], &new_in[0], NULL);
      else
        new_in[0] = NULL;

      /* input "max_bond_length" is Value */
      new_in[1] = in[1];

      /* input "max_number_bonds" is Value */
      new_in[2] = in[2];

      /*
       * For all outputs that are Values, copy them to 
       * child object list.  For all that are Field/Group,  get
       * the appropriate decendent and place it into the
       * child output object list.  Note that none should
       * be NULL (unlike inputs, which can default).
       */

      /* output "balls_with_connections" is Field/Group */
      DXGetXformInfo((Xform)out[0], &new_out[0], NULL);

      /* output "sticks" is Field/Group */
      DXGetXformInfo((Xform)out[1], &new_out[1], NULL);

      if (! traverse(new_in, new_out))
        return ERROR;

      /*
       * Now for each output that is not a Value replace
       * the updated child into the object in the parent.
       */

      /* output "balls_with_connections" is Field/Group */
      DXSetXformObject((Xform)out[0], new_out[0]);

      /* output "sticks" is Field/Group */
      DXSetXformObject((Xform)out[1], new_out[1]);

      return OK;
    }

    case CLASS_SCREEN:
    {
      int    i, j;
      Object new_in[3], new_out[2];


      /*
       * Create new in and out lists for the decendent of the
       * first input.  For inputs and outputs that are Values
       * copy them into the new in and out lists.  Otherwise
       * get the corresponding decendents.
       */

      /* input "balls" is Field/Group */
      if (in[0])
        DXGetScreenInfo((Screen)in[0], &new_in[0], NULL, NULL);
      else
        new_in[0] = NULL;

      /* input "max_bond_length" is Value */
      new_in[1] = in[1];

      /* input "max_number_bonds" is Value */
      new_in[2] = in[2];


      /*
       * For all outputs that are Values, copy them to 
       * child object list.  For all that are Field/Group,  get
       * the appropriate decendent and place it into the
       * child output object list.  Note that none should
       * be NULL (unlike inputs, which can default).
       */

       /* output "balls_with_connections" is Field/Group */
       DXGetScreenInfo((Screen)out[0], &new_out[0], NULL, NULL);

       /* output "sticks" is Field/Group */
       DXGetScreenInfo((Screen)out[1], &new_out[1], NULL, NULL);

       if (! traverse(new_in, new_out))
         return ERROR;

      /*
       * Now for each output that is not a Value, replace
       * the updated child into the object in the parent.
       */

      /* output "balls_with_connections" is Field/Group */
       DXSetScreenObject((Screen)out[0], new_out[0]);

      /* output "sticks" is Field/Group */
       DXSetScreenObject((Screen)out[1], new_out[1]);

       return OK;
     }

     case CLASS_CLIPPED:
     {
       int    i, j;
       Object new_in[3], new_out[2];


       /* input "balls" is Field/Group */
       if (in[0])
         DXGetClippedInfo((Clipped)in[0], &new_in[0], NULL);
       else
         new_in[0] = NULL;

       /* input "max_bond_length" is Value */
       new_in[1] = in[1];

       /* input "max_number_bonds" is Value */
       new_in[2] = in[2];


      /*
       * For all outputs that are Values, copy them to 
       * child object list.  For all that are Field/Group,  get
       * the appropriate decendent and place it into the
       * child output object list.  Note that none should
       * be NULL (unlike inputs, which can default).
       */

       /* output "balls_with_connections" is Field/Group */
       DXGetClippedInfo((Clipped)out[0], &new_out[0], NULL);

       /* output "sticks" is Field/Group */
       DXGetClippedInfo((Clipped)out[1], &new_out[1], NULL);

       if (! traverse(new_in, new_out))
         return ERROR;

      /*
       * Now for each output that is not a Value, replace
       * the updated child into the object in the parent.
       */

       /* output "balls_with_connections" is Field/Group */
       DXSetClippedObjects((Clipped)out[0], new_out[0], NULL);

       /* output "sticks" is Field/Group */
       DXSetClippedObjects((Clipped)out[1], new_out[1], NULL);

       return OK;
     }

     default:
     {
       DXSetError(ERROR_BAD_CLASS, "encountered in object traversal");
       return ERROR;
     }
  }
}

static int
doLeaf(Object *in, Object *out)
{
  int i, result=0;
  Array array;
  Field field;
  Pointer *in_data[3], *out_data[2];
  int in_knt[3], out_knt[2];
  Type type;
  Category category;
  int rank, shape;
  Object attr, src_dependency_attr = NULL;
  char *src_dependency = NULL;
  /*
   * Irregular positions info
   */
  int p_knt, p_dim;
  float *p_positions;
  int c_knt = -1;



  /* BERND */
  float *out_ptr, *in_ptr, max_bond_length;
  int con_count,ivec[2],nr,j, max_num_bonds;
  float ri[3],d[3],dis,sqd;
  float *r;
  int *bond_cnt;
  char mstring[255];
  Array arrayconn1, arrayconn2, arraydata2;
  

  /* ==================== HANDLE INPUT FIELD ==========================*/


  /*
   * positions and/or connections are required, so the first must
   * be a field.
   */
  if (DXGetObjectClass(in[0]) != CLASS_FIELD)
  {
      DXSetError(ERROR_INVALID_DATA,
           "positions and/or connections unavailable in array object");
      goto error;
  }
  else
  {

    field = (Field)in[0];

    if (DXEmptyField(field))
      return OK;

    /* 
     * Determine the dependency of the source object's data
     * component.
     */
    src_dependency_attr = DXGetComponentAttribute(field, "data", "dep");
    if (! src_dependency_attr)
    {
      DXSetError(ERROR_MISSING_DATA, "\"balls\" data component is missing a dependency attribute");
      goto error;
    }

    if (DXGetObjectClass(src_dependency_attr) != CLASS_STRING)
    {
      DXSetError(ERROR_BAD_CLASS, "\"balls\" dependency attribute");
      goto error;
    }

    src_dependency = DXGetString((String)src_dependency_attr);

    array = (Array)DXGetComponentValue(field, "positions");
    if (! array)
    {
      DXSetError(ERROR_BAD_CLASS, "\"balls\" contains no positions component");
      goto error;
    }

    /* 
     * The user requested irregular positions.  So we
     * get the count, the dimensionality and a pointer to the
     * explicitly enumerated positions.  If the positions
     * are in fact regular, this will expand them.
     */
    DXGetArrayInfo(array, &p_knt, NULL, NULL, NULL, &p_dim);

    p_positions = (float *)DXGetArrayData(array);
    if (! p_positions)
      goto error;

    /* 
     * If there are connections, get their count so that
     * connections-dependent result arrays can be sized.
     */
    array = (Array)DXGetComponentValue(field, "connections");
    if (array)
        DXGetArrayInfo(array, &c_knt, NULL, NULL, NULL, NULL);
  }
  /*
   * If the input argument is not NULL then we get the 
   * data array: either the object itself, if its an 
   * array, or the data component if the argument is a field
   */
  if (! in[0])
  {
    array = NULL;
    in_data[0] = NULL;
    in_knt[0] = NULL;
  }
  else
  {
    if (DXGetObjectClass(in[0]) == CLASS_ARRAY)
    {
      array = (Array)in[0];
    }
    else if (DXGetObjectClass(in[0]) == CLASS_STRING)
    {
      in_data[0] = (Pointer)DXGetString((String)in[0]);
      in_knt[0] = 1;
    }
    else
    {
      if (DXGetObjectClass(in[0]) != CLASS_FIELD)
      {
        DXSetError(ERROR_BAD_CLASS, "\"balls\" should be a field");
        goto error;
      }

      array = (Array)DXGetComponentValue((Field)in[0], "data");
      if (! array)
      {
        DXSetError(ERROR_MISSING_DATA, "\"balls\" has no data component");
        goto error;
      }

      if (DXGetObjectClass((Object)array) != CLASS_ARRAY)
      {
        DXSetError(ERROR_BAD_CLASS, "data component of \"balls\" should be an array");
        goto error;
      }
    }

    /* 
     * get the dependency of the data component
     */
    attr = DXGetAttribute((Object)array, "dep");
    if (! attr)
    {
      DXSetError(ERROR_MISSING_DATA, "data component of \"balls\" has no dependency");
      goto error;
    }

    if (DXGetObjectClass(attr) != CLASS_STRING)
    {
      DXSetError(ERROR_BAD_CLASS, "dependency attribute of data component of \"balls\"");
      goto error;
    }

    if (DXGetObjectClass(in[0]) != CLASS_STRING)    {
       DXGetArrayInfo(array, &in_knt[0], &type, &category, &rank, &shape);
       if (type != TYPE_FLOAT || category != CATEGORY_REAL ||
             !((rank == 0) || ((rank == 1)&&(shape == 1))))
       {
	 if(type != TYPE_FLOAT) 
	   sprintf(mstring,"INCORRECT DATA TYPE: SHOULD BE FLOAT");

	 if(category != CATEGORY_REAL) 
	   sprintf(mstring,"INCORRECT CATEGORY: SHOULD BE CATEGORY_REAL");

	 if(!((rank == 0) || ((rank == 1)&&(shape == 1))))
	   sprintf(mstring,"RANK=%d AND SHAPE=%d ARE INCORRECT",rank,shape);

	 DXMessage(mstring);

         DXSetError(ERROR_INVALID_DATA, "input \"balls\"");
         goto error;
       }

       in_data[0] = DXGetArrayData(array);
       if (! in_data[0])
          goto error;

    }

  }
  /* ==================== HANDLE INPUT BOND LENGTH =========================*/



  /*
   * If the input argument is not NULL then we get the 
   * data array: either the object itself, if its an 
   * array, or the data component if the argument is a field
   */
  if (! in[1])
  {
    array = NULL;
    in_data[1] = NULL;
    in_knt[1] = NULL;
  }
  else
  {
    if (DXGetObjectClass(in[1]) == CLASS_ARRAY)
    {
      array = (Array)in[1];
    }
    else if (DXGetObjectClass(in[1]) == CLASS_STRING)
    {
      in_data[1] = (Pointer)DXGetString((String)in[1]);
      in_knt[1] = 1;
    }
    else
    {
      if (DXGetObjectClass(in[1]) != CLASS_FIELD)
      {
        DXSetError(ERROR_BAD_CLASS, "\"max_bond_length\" should be a field");
        goto error;
      }

      array = (Array)DXGetComponentValue((Field)in[1], "data");
      if (! array)
      {
        DXSetError(ERROR_MISSING_DATA, "\"max_bond_length\" has no data component");
        goto error;
      }

      if (DXGetObjectClass((Object)array) != CLASS_ARRAY)
      {
        DXSetError(ERROR_BAD_CLASS, "data component of \"max_bond_length\" should be an array");
        goto error;
      }
    }


    if (DXGetObjectClass(in[1]) != CLASS_STRING)    {
       DXGetArrayInfo(array, &in_knt[1], &type, &category, &rank, &shape);
       if (type != TYPE_FLOAT || category != CATEGORY_REAL ||
             !((rank == 0) || ((rank == 1)&&(shape == 1))))
       {
         DXSetError(ERROR_INVALID_DATA, "input \"max_bond_length\"");
         goto error;
       }

       in_data[1] = DXGetArrayData(array);
       if (! in_data[1])
          goto error;

    }
  }
  /* =========== HANDLE INPUT MAX NUM BONDS ============================*/



  /*
   * If the input argument is not NULL then we get the 
   * data array: either the object itself, if its an 
   * array, or the data component if the argument is a field
   */
  if (! in[2])
  {
    array = NULL;
    in_data[2] = NULL;
    in_knt[2] = NULL;
  }
  else
  {
    if (DXGetObjectClass(in[2]) == CLASS_ARRAY)
    {
      array = (Array)in[2];
    }
    else if (DXGetObjectClass(in[2]) == CLASS_STRING)
    {
      in_data[2] = (Pointer)DXGetString((String)in[2]);
      in_knt[2] = 1;
    }
    else
    {
      if (DXGetObjectClass(in[2]) != CLASS_FIELD)
      {
        DXSetError(ERROR_BAD_CLASS, "\"max_number_bonds\" should be a field");
        goto error;
      }

      array = (Array)DXGetComponentValue((Field)in[2], "data");
      if (! array)
      {
        DXSetError(ERROR_MISSING_DATA, "\"max_number_bonds\" has no data component");
        goto error;
      }

      if (DXGetObjectClass((Object)array) != CLASS_ARRAY)
      {
        DXSetError(ERROR_BAD_CLASS, "data component of \"max_number_bonds\" should be an array");
        goto error;
      }
    }


    if (DXGetObjectClass(in[2]) != CLASS_STRING)    {
       DXGetArrayInfo(array, &in_knt[2], &type, &category, &rank, &shape);
       if (type != TYPE_INT || category != CATEGORY_REAL ||
             !((rank == 0) || ((rank == 1)&&(shape == 1))))
       {
         DXSetError(ERROR_INVALID_DATA, "input \"max_number_bonds\"");
         goto error;
       }

       in_data[2] = DXGetArrayData(array);
       if (! in_data[2])
          goto error;

    }
  }

  /* =========== done with checking the input ================= */



  /* ===== create output array 0 for the balls ====== */

  /*
   * Create an output data array typed according to the
   * specification given
   */
  array = DXNewArray(TYPE_FLOAT, CATEGORY_REAL, 0, 0);
  if (! array)
    goto error;

  /*
   * Set the dependency of the array to the same as the first input
   */
  if (src_dependency_attr != NULL)
    if (! DXSetAttribute((Object)array, "dep", src_dependency_attr))
      goto error;

  /*
   * The size and dependency of this output data array will 
   * match that of input[0]
   */
  out_knt[0] = in_knt[0];
  /*
   * Actually allocate the array data space
   */
  if (! DXAddArrayData(array, 0, out_knt[0], NULL))
    goto error;

  /*
   * If the output vector slot is not NULL, then it better be a field, and
   * we'll add the new array to it as its data component (delete any prior
   * data component so that its attributes won't overwrite the new component's)
   * Otherwise, place the new array into the out vector.
   */
  if (out[0])
  {
    if (DXGetObjectClass(out[0]) != CLASS_FIELD)
    {
      DXSetError(ERROR_INTERNAL, "non-field object found in output vector");
      goto error;
    }

    if (DXGetComponentValue((Field)out[0], "data"))
      DXDeleteComponent((Field)out[0], "data");

    if (! DXSetComponentValue((Field)out[0], "data", (Object)array))
      goto error;

  }
  else
    out[0] = (Object)array;
  /*
   * Now get the pointer to the contents of the array
   */
  out_data[0] = DXGetArrayData(array);
  if (! out_data[0])
    goto error;



  /* ===== create output array 1 for the sticks ====== */

  /*
   * Create an output data array typed according to the
   * specification given
   */
  array = DXNewArray(TYPE_FLOAT, CATEGORY_REAL, 0, 0);
  if (! array)
    goto error;

  /*
   * Set the dependency of the array to be connections
   */

  if (! DXSetAttribute((Object)array, "dep", 
		       (Object)DXNewString("connections")))
    goto error;

  /*
   * The size of this output data array will 
   * match that of input[0]
   */
  out_knt[1] = in_knt[0];
  /*
   * Actually allocate the array data space
   */
  if (! DXAddArrayData(array, 0, out_knt[1], NULL))
    goto error;

  /*
   * If the output vector slot is not NULL, then it better be a field, and
   * we'll add the new array to it as its data component (delete any prior
   * data component so that its attributes won't overwrite the new component's)
   * Otherwise, place the new array into the out vector.
   */
  if (out[1])
  {
    if (DXGetObjectClass(out[1]) != CLASS_FIELD)
    {
      DXSetError(ERROR_INTERNAL, "non-field object found in output vector");
      goto error;
    }

    if (DXGetComponentValue((Field)out[1], "data"))
      DXDeleteComponent((Field)out[1], "data");

    if (! DXSetComponentValue((Field)out[1], "data", (Object)array))
      goto error;

  }
  else
    out[1] = (Object)array;
  /*
   * Now get the pointer to the contents of the array
   */
  out_data[1] = DXGetArrayData(array);
  if (! out_data[1])
    goto error;


  /* ========================= WORKER ROUTINE ========================== */

  /* BERND 
   *           copy the data into the output field */

  out_ptr = (float *)out_data[0];
  in_ptr  = (float *)in_data[0];

  for(i=0;i<out_knt[0]; i++) {
    *out_ptr=*in_ptr;
    in_ptr++; out_ptr++;
  }

  con_count=0;

  /* ==== allocate array for connections of first output field == */

  arrayconn1 = (Array)DXGetComponentValue((Field)in[0], "connections");

  if (arrayconn1) { 
    DXGetArrayInfo(arrayconn1, &con_count, &type, &category, &rank, &shape);

    if( type!=TYPE_INT || category !=CATEGORY_REAL || rank!=1 || shape !=2) {
         DXSetError(ERROR_INVALID_DATA, "existing connections are no sticks!");
         goto error;
       }
  }
  else {
    arrayconn1 = DXNewArray(TYPE_INT, CATEGORY_REAL, 1,2);
  }

  /* ==== allocate array for connections of second output field == */

  arrayconn2 = DXNewArray(TYPE_INT, CATEGORY_REAL, 1,2);

  /* ==== allocate array for data of  second output field == */

  arraydata2 = DXNewArray(TYPE_FLOAT, CATEGORY_REAL, 0,1);


  r               = (float *) p_positions;
  nr              = p_knt;

  if(in_data[1]) max_bond_length = *((float *)(in_data[1]));
  else max_bond_length=2.2;

  max_bond_length*=max_bond_length;

  if(in_data[2])  max_num_bonds = *((int *)(in_data[2]));
  else max_num_bonds =4;

  
  bond_cnt = (int *) malloc(nr*sizeof(int));
  for(i=0; i<nr; i++) bond_cnt[i]=0;

  for(i=0; i<nr; i++) {
    ri[0]=r[3*i];
    ri[1]=r[3*i+1];
    ri[2]=r[3*i+2];
    for(j=i+1; j<nr; j++) {
      d[0]=ri[0]-r[3*j];
      d[1]=ri[1]-r[3*j+1];
      d[2]=ri[2]-r[3*j+2];
      dis=d[0]*d[0]+d[1]*d[1]+d[2]*d[2];

      if(dis<max_bond_length) {
	if(bond_cnt[i]<max_num_bonds && bond_cnt[j]<max_num_bonds) {
	  bond_cnt[i]++;
	  bond_cnt[j]++;
	  ivec[0]=i;
	  ivec[1]=j;
	  /* add new connection to first output array */
	  if(!DXAddArrayData(arrayconn1, con_count, 1,(Pointer)ivec)) 
	    goto error;
	  /* add new connection to second output array */
	  if(!DXAddArrayData(arrayconn2, con_count, 1,(Pointer)ivec)) 
	    goto error;
	  /* add bond length as data component to second output array */
	  sqd = (float) sqrt((double)dis);
	  if(!DXAddArrayData(arraydata2, con_count, 1, 
			     (Pointer) (&sqd))) 
	    goto error;
	  con_count++;
	}
      }
    }
  }

  free(bond_cnt);


  /* ====  set attributes for first output array, and link it in === */

  if(DXGetAttribute((Object)arrayconn1,"element type"))
     DXDeleteAttribute((Object)arrayconn1,"element type");
  DXSetStringAttribute((Object)arrayconn1,"element type","lines");

  if(DXGetAttribute((Object)arrayconn1,"ref"))
     DXDeleteAttribute((Object)arrayconn1,"ref");
  DXSetStringAttribute((Object)arrayconn1,"ref","positions");

  DXSetComponentValue((Field)out[0],"connections",(Object) arrayconn1);


  /* finalize the field */
  DXEndField((Field)out[0]); 


  /* ====  set attributes for second output array, and link it in === */

  if(DXGetAttribute((Object)arrayconn2,"element type"))
     DXDeleteAttribute((Object)arrayconn2,"element type");
  DXSetStringAttribute((Object)arrayconn2,"element type","lines");

  if(DXGetAttribute((Object)arrayconn2,"ref"))
     DXDeleteAttribute((Object)arrayconn2,"ref");
  DXSetStringAttribute((Object)arrayconn2,"ref","positions");

  DXSetComponentValue((Field)out[1],"connections",(Object) arrayconn2);


  if(DXGetAttribute((Object)arraydata2,"dep"))
     DXDeleteAttribute((Object)arraydata2,"dep");
  DXSetStringAttribute((Object)arraydata2,"dep","connections");

  DXSetComponentValue((Field)out[1],"data",(Object) arraydata2);


  /* finalize the field */
  DXEndField((Field)out[1]); 

  result=1;


error:
  return result;
}

int
AddSticks_worker(
    int p_knt, int p_dim, float *p_positions,
    int balls_knt, float *balls_data,
    int max_bond_length_knt, float *max_bond_length_data,
    int max_number_bonds_knt, int *max_number_bonds_data,
    int balls_with_connections_knt, float *balls_with_connections_data,
    int sticks_knt, float *sticks_data)
{
  /*
   * The arguments to this routine are:
   *
   *  p_knt:           total count of input positions
   *  p_dim:           dimensionality of input positions
   *  p_positions:     pointer to positions list
   *
   * The following are inputs and therefore are read-only.  The default
   * values are given and should be used if the knt is 0.
   *
   * balls_knt, balls_data:  count and pointer for input "balls"
   *                   no default value given.
   * max_bond_length_knt, max_bond_length_data:  count and pointer for input "max_bond_length"
   *                   non-descriptive default value is "2.2"
   * max_number_bonds_knt, max_number_bonds_data:  count and pointer for input "max_number_bonds"
   *                   non-descriptive default value is "4"
   *
   *  The output data buffer(s) are writable.
   *  The output buffer(s) are preallocated based on
   *     the dependency (positions or connections),
   *     the size of the corresponding positions or
   *     connections component in the first input, and
   *     the data type.
   *
   * balls_with_connections_knt, balls_with_connections_data:  count and pointer for output "balls_with_connections"
   * sticks_knt, sticks_data:  count and pointer for output "sticks"
   */

  /*
   * User's code goes here
   */
     
     
  /*
   * successful completion
   */
   return 1;
     
  /*
   * unsuccessful completion
   */
error:
   return 0;
  
}
