/* Automatically generated - do not edit! */

#include <dx/dx.h>
#include <dx/modflags.h>

DXEntry()
{
    {
        extern Error m_ReplicateCell2D(Object *, Object *);
        DXAddModule("ReplicateCell2D", m_ReplicateCell2D, 0,
            3, "udata_field", "replication_dim", "lattice_vectors",
            1, "replicated_field");
    }
}
