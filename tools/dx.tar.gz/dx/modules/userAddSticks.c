/* Automatically generated - do not edit! */

#include <dx/dx.h>
#include <dx/modflags.h>

DXEntry()
{
    {
        extern Error m_AddSticks(Object *, Object *);
        DXAddModule("AddSticks", m_AddSticks, 0,
            3, "balls", "max_bond_length", "max_number_bonds",
            2, "balls_with_connections", "sticks");
    }
}
