/*
 * Automatically generated on "/tmp/ReplicateCell.mb" by DX Module Builder
 */

#include "dx/dx.h"

static Error traverse(Object *, Object *);
static Error doLeaf(Object *, Object *);

/*
 * Declare the interface routine.
 */
int
ReplicateCell_worker(
    int, int, float *,
    int, float *,
    int, float *,
    int, float *,
    int, float *);

Error
m_ReplicateCell(Object *in, Object *out)
{
  int i;

  /*
   * Initialize all outputs to NULL
   */
  out[0] = NULL;

  /*
   * Error checks: required inputs are verified.
   */

  /* Parameter "udata_field" is required. */
  if (in[0] == NULL)
  {
    DXSetError(ERROR_MISSING_DATA, "\"udata_field\" must be specified");
    return ERROR;
  }

  /* Parameter "lattice_vectors" is required. */
  if (in[2] == NULL)
  {
    DXSetError(ERROR_MISSING_DATA, "\"lattice_vectors\" must be specified");
    return ERROR;
  }


  /*
   * Since output "replicated_field" is structure Field/Group, it initially
   * is a copy of input "udata_field".
   */
  out[0] = DXCopy(in[0], COPY_STRUCTURE);
  if (! out[0])
    goto error;

  /*
   * If in[0] was an array, then no copy is actually made - Copy 
   * returns a pointer to the input object.  Since this can't be written to
   * we postpone explicitly copying it until the leaf level, when we'll need
   * to be creating writable arrays anyway.
   */
  if (out[0] == in[0])
    out[0] = NULL;

  /*
   * Call the hierarchical object traversal routine
   */
  if (!traverse(in, out))
    goto error;

  return OK;

error:
  /*
   * On error, any successfully-created outputs are deleted.
   */
  for (i = 0; i < 1; i++)
  {
    if (in[i] != out[i])
      DXDelete(out[i]);
    out[i] = NULL;
  }
  return ERROR;
}


static Error
traverse(Object *in, Object *out)
{
  switch(DXGetObjectClass(in[0]))
  {
    case CLASS_FIELD:
    case CLASS_ARRAY:
    case CLASS_STRING:
      /*
       * If we have made it to the leaf level, call the leaf handler.
       */
      if (! doLeaf(in, out))
  	     return ERROR;

      return OK;

    case CLASS_GROUP:
    {
      int   i, j;
      int   memknt;
      Class groupClass  = DXGetGroupClass((Group)in[0]);

      DXGetMemberCount((Group)in[0], &memknt);


       /*
        * Create new in and out lists for each child
        * of the first input. 
        */
        for (i = 0; i < memknt; i++)
        {
          Object new_in[3], new_out[1];

         /*
          * For all inputs that are Values, pass them to 
          * child object list.  For all that are Field/Group, get 
          * the appropriate decendent and place it into the
          * child input object list.
          */

          /* input "udata_field" is Field/Group */
          if (in[0])
            new_in[0] = DXGetEnumeratedMember((Group)in[0], i, NULL);
          else
            new_in[0] = NULL;

          /* input "replication_dim" is Value */
          new_in[1] = in[1];

          /* input "lattice_vectors" is Value */
          new_in[2] = in[2];

         /*
          * For all outputs that are Values, pass them to 
          * child object list.  For all that are Field/Group,  get
          * the appropriate decendent and place it into the
          * child output object list.  Note that none should
          * be NULL (unlike inputs, which can default).
          */

          /* output "replicated_field" is Field/Group */
          new_out[0] = DXGetEnumeratedMember((Group)out[0], i, NULL);

          if (! traverse(new_in, new_out))
            return ERROR;

         /*
          * Now for each output that is not a Value, replace
          * the updated child into the object in the parent.
          */

          /* output "replicated_field" is Field/Group */
          DXSetEnumeratedMember((Group)out[0], i, new_out[0]);

        }
      return OK;
    }

    case CLASS_XFORM:
    {
      int    i, j;
      Object new_in[3], new_out[1];


      /*
       * Create new in and out lists for the decendent of the
       * first input.  For inputs and outputs that are Values
       * copy them into the new in and out lists.  Otherwise
       * get the corresponding decendents.
       */

      /* input "udata_field" is Field/Group */
      if (in[0])
        DXGetXformInfo((Xform)in[0], &new_in[0], NULL);
      else
        new_in[0] = NULL;

      /* input "replication_dim" is Value */
      new_in[1] = in[1];

      /* input "lattice_vectors" is Value */
      new_in[2] = in[2];

      /*
       * For all outputs that are Values, copy them to 
       * child object list.  For all that are Field/Group,  get
       * the appropriate decendent and place it into the
       * child output object list.  Note that none should
       * be NULL (unlike inputs, which can default).
       */

      /* output "replicated_field" is Field/Group */
      DXGetXformInfo((Xform)out[0], &new_out[0], NULL);

      if (! traverse(new_in, new_out))
        return ERROR;

      /*
       * Now for each output that is not a Value replace
       * the updated child into the object in the parent.
       */

      /* output "replicated_field" is Field/Group */
      DXSetXformObject((Xform)out[0], new_out[0]);

      return OK;
    }

    case CLASS_SCREEN:
    {
      int    i, j;
      Object new_in[3], new_out[1];


      /*
       * Create new in and out lists for the decendent of the
       * first input.  For inputs and outputs that are Values
       * copy them into the new in and out lists.  Otherwise
       * get the corresponding decendents.
       */

      /* input "udata_field" is Field/Group */
      if (in[0])
        DXGetScreenInfo((Screen)in[0], &new_in[0], NULL, NULL);
      else
        new_in[0] = NULL;

      /* input "replication_dim" is Value */
      new_in[1] = in[1];

      /* input "lattice_vectors" is Value */
      new_in[2] = in[2];


      /*
       * For all outputs that are Values, copy them to 
       * child object list.  For all that are Field/Group,  get
       * the appropriate decendent and place it into the
       * child output object list.  Note that none should
       * be NULL (unlike inputs, which can default).
       */

       /* output "replicated_field" is Field/Group */
       DXGetScreenInfo((Screen)out[0], &new_out[0], NULL, NULL);

       if (! traverse(new_in, new_out))
         return ERROR;

      /*
       * Now for each output that is not a Value, replace
       * the updated child into the object in the parent.
       */

      /* output "replicated_field" is Field/Group */
       DXSetScreenObject((Screen)out[0], new_out[0]);

       return OK;
     }

     case CLASS_CLIPPED:
     {
       int    i, j;
       Object new_in[3], new_out[1];


       /* input "udata_field" is Field/Group */
       if (in[0])
         DXGetClippedInfo((Clipped)in[0], &new_in[0], NULL);
       else
         new_in[0] = NULL;

       /* input "replication_dim" is Value */
       new_in[1] = in[1];

       /* input "lattice_vectors" is Value */
       new_in[2] = in[2];


      /*
       * For all outputs that are Values, copy them to 
       * child object list.  For all that are Field/Group,  get
       * the appropriate decendent and place it into the
       * child output object list.  Note that none should
       * be NULL (unlike inputs, which can default).
       */

       /* output "replicated_field" is Field/Group */
       DXGetClippedInfo((Clipped)out[0], &new_out[0], NULL);

       if (! traverse(new_in, new_out))
         return ERROR;

      /*
       * Now for each output that is not a Value, replace
       * the updated child into the object in the parent.
       */

       /* output "replicated_field" is Field/Group */
       DXSetClippedObjects((Clipped)out[0], new_out[0], NULL);

       return OK;
     }

     default:
     {
       DXSetError(ERROR_BAD_CLASS, "encountered in object traversal");
       return ERROR;
     }
  }
}

static int
doLeaf(Object *in, Object *out)
{
  int i, result=0;
  Array array;
  Field field;
  Pointer *in_data[3], *out_data[1];
  int in_knt[3], out_knt[1];
  Type type;
  Category category;
  int rank, shape;
  Object attr, src_dependency_attr = NULL;
  char *src_dependency = NULL;
  /* BERND
   * my variables */
  int irep[3],ldx,ldy,ldz,lx,ly,lz,kx,ky,kz; 
  Class pclass;
  Array carray;
  Array ncarray;
  Array parray;    /* space for  regular arrays for positions*/
  Array nparray;    /* space for new regular arrays for positions*/
  int dshape;      /* shape of input data */
  int drank;

  int nterms;
  int rcounts[3];
  int orcounts[3]; /* original rcounts */
  float rorigin[3], rdeltas[3][3];
  
  float *outdatapoi;  /* pointer to the output data */
  float npos[3];
  float *lvec;   /* pointer to the translation data */
  char mstring[255];
  int j,k,l,ic,ldain; /* dummies */
  Array outpos;       /* array containing the output positions */
  Point *outpospoi;   /* pointer to the output positions */

  /*
   * Irregular positions info
   */
  int p_knt, p_dim;
  float *p_positions;
  int c_knt = -1;

  /*
   * positions and/or connections are required, so the first must
   * be a field.
   */


  /* =================== HANDLE THE FIRST INPUT ========================*/
  /*                       (DATA FIELD ITSELF)            */


  if (DXGetObjectClass(in[0]) != CLASS_FIELD)
  {
      DXSetError(ERROR_INVALID_DATA,
           "positions and/or connections unavailable in array object");
      goto error;
  }
  else
  {

    field = (Field)in[0];

    if (DXEmptyField(field))
      return OK;

    /* 
     * Determine the dependency of the source object's data
     * component.
     */
    src_dependency_attr = DXGetComponentAttribute(field, "data", "dep");
    if (! src_dependency_attr)
    {
      DXSetError(ERROR_MISSING_DATA, "\"udata_field\" data component is missing a dependency attribute");
      goto error;
    }

    if (DXGetObjectClass(src_dependency_attr) != CLASS_STRING)
    {
      DXSetError(ERROR_BAD_CLASS, "\"udata_field\" dependency attribute");
      goto error;
    }

    src_dependency = DXGetString((String)src_dependency_attr);
    /*
     * Figure out the position type and act accordingly 
     * 
     */
    parray = (Array)DXGetComponentValue(field, "positions");
    if (!parray)
    {
      DXSetError(ERROR_BAD_CLASS, 
		 "\"udata_field\" contains no positions component");
      goto error;
    }

    pclass = DXGetArrayClass(parray);

    if(pclass == CLASS_ARRAY) {
      /* sprintf(mstring,"Irregular positions found, processing...");
	 DXMessage(mstring); */

      /* 
       * Get the count, the dimensionality and a pointer to the
       * explicitly enumerated positions.  If the positions
       * are in fact regular, this will expand them.
       */
      DXGetArrayInfo(parray, &p_knt, NULL, NULL, NULL, &p_dim);

      p_positions = (float *)DXGetArrayData(parray);
      if (! p_positions)
	goto error;
    } 
    else {
      if(pclass != CLASS_PRODUCTARRAY) {
	DXSetError(ERROR_BAD_CLASS, 
		   "\"udata_field\" must have 3d regular positions component");
	goto error;
      }
      /* 
       * We have regular positions as input. Just increase the sizes
       * accordingly, and no need to touch positions.
       */
      /* sprintf(mstring,"Regular positions found.");
	 DXMessage(mstring); */

    }

    /* 
     * If there are connections, get their count so that
     * connections-dependent result arrays can be sized.
     */
    carray = (Array)DXGetComponentValue(field, "connections");
    if (carray) {
      DXGetArrayInfo(carray, &c_knt, NULL, NULL, NULL, NULL);
      if(pclass != CLASS_PRODUCTARRAY) {
	DXSetError(ERROR_BAD_CLASS, 
		   "connections not yet handled for irregular positions");
	goto error;
      }


    }
  }
  /*
   * If the input argument is not NULL then we get the 
   * data array: either the object itself, if its an 
   * array, or the data component if the argument is a field
   */
  if (! in[0])
  {
    array = NULL;
    in_data[0] = NULL;
    in_knt[0] = NULL;
  }
  else
  {
    if (DXGetObjectClass(in[0]) == CLASS_ARRAY)
    {
      array = (Array)in[0];
    }
    else if (DXGetObjectClass(in[0]) == CLASS_STRING)
    {
      in_data[0] = (Pointer)DXGetString((String)in[0]);
      in_knt[0] = 1;
    }
    else
    {
      if (DXGetObjectClass(in[0]) != CLASS_FIELD)
      {
        DXSetError(ERROR_BAD_CLASS, "\"udata_field\" should be a field");
        goto error;
      }

      array = (Array)DXGetComponentValue((Field)in[0], "data");
      if (! array)
      {
        DXSetError(ERROR_MISSING_DATA, "\"udata_field\" has no data component");
        goto error;
      }

      if (DXGetObjectClass((Object)array) != CLASS_ARRAY)
      {
        DXSetError(ERROR_BAD_CLASS, "data component of \"udata_field\" should be an array");
        goto error;
      }
    }

    /* 
     * get the dependency of the data component
     */
    attr = DXGetAttribute((Object)array, "dep");
    if (! attr)
    {
      DXSetError(ERROR_MISSING_DATA, "data component of \"udata_field\" has no dependency");
      goto error;
    }

    if (DXGetObjectClass(attr) != CLASS_STRING)
    {
      DXSetError(ERROR_BAD_CLASS, "dependency attribute of data component of \"udata_field\"");
      goto error;
    }


    if (DXGetObjectClass(in[0]) != CLASS_STRING)    {
       DXGetArrayInfo(array, &in_knt[0], &type, &category, &drank, &dshape);

       if (type != TYPE_FLOAT ||    
	   category != CATEGORY_REAL || (drank!=0 && drank!=1) )
       {
         DXSetError(ERROR_INVALID_DATA, "input \"udata_field\"");
         goto error;
       }

       in_data[0] = DXGetArrayData(array);
       if (! in_data[0])
          goto error;


    }
  }


  /* =================== HANDLE INPUT 2      ========================*/
  /*                     (replication vectors) */

  /*
   * If the input argument is not NULL then we get the 
   * data array: either the object itself, if its an 
   * array, or the data component if the argument is a field
   */
  if (! in[1])
  {
    sprintf(mstring,"replication vectors missing!");
    DXMessage(mstring);

    array = NULL;
    in_data[1] = NULL;
    in_knt[1] = NULL;
  }
  else
  {
    if (DXGetObjectClass(in[1]) == CLASS_ARRAY)
    {
      array = (Array)in[1];
    }
    else if (DXGetObjectClass(in[1]) == CLASS_STRING)
    {
      in_data[1] = (Pointer)DXGetString((String)in[1]);
      in_knt[1] = 1;
    }
    else
    {
      if (DXGetObjectClass(in[1]) != CLASS_FIELD)
      {
        DXSetError(ERROR_BAD_CLASS, "\"replication_dim\" should be a field");
        goto error;
      }

      array = (Array)DXGetComponentValue((Field)in[1], "data");
      if (! array)
      {
        DXSetError(ERROR_MISSING_DATA, 
		   "\"replication_dim\" has no data component");
        goto error;
      }

      if (DXGetObjectClass((Object)array) != CLASS_ARRAY)
      {
        DXSetError(ERROR_BAD_CLASS, 
		   "data component of \"replication_dim\" should be an array");
        goto error;
      }
    }


    if (DXGetObjectClass(in[1]) != CLASS_STRING)    {
       DXGetArrayInfo(array, &in_knt[1], &type, &category, &rank, &shape);
       if (type != TYPE_INT || category != CATEGORY_REAL ||
           rank != 1 || shape != 3)
       {
	 /* BERND      print out more instructive error message */
	 if(type != TYPE_INT)
	 sprintf(mstring,"Replication numbers MUST BE INTEGERS!");
	 DXMessage(mstring);
         DXSetError(ERROR_INVALID_DATA, "input \"replication_dim\"");
         goto error;
       }

       in_data[1] = DXGetArrayData(array);
       if (! in_data[1])
          goto error;

    }
  }

  /* =================== HANDLE INPUT 3      ========================*/
  /*                     (lattice vectors) */
  /*
   * If the input argument is not NULL then we get the 
   * data array: either the object itself, if its an 
   * array, or the data component if the argument is a field
   */
  if (! in[2])
  {
    sprintf(mstring,"Missing cell replication data");
    DXMessage(mstring);

    array = NULL;
    in_data[2] = NULL;
    in_knt[2] = NULL;
  }
  else
  {
    if (DXGetObjectClass(in[2]) == CLASS_ARRAY)
    {
      array = (Array)in[2];
    }
    else if (DXGetObjectClass(in[2]) == CLASS_STRING)
    {
      in_data[2] = (Pointer)DXGetString((String)in[2]);
      in_knt[2] = 1;
    }
    else
    {
      if (DXGetObjectClass(in[2]) != CLASS_FIELD)
      {
        DXSetError(ERROR_BAD_CLASS, "\"lattice_vectors\" should be a field");
        goto error;
      }

      array = (Array)DXGetComponentValue((Field)in[2], "data");
      if (! array)
      {
        DXSetError(ERROR_MISSING_DATA, "\"lattice_vectors\" has no data component");
        goto error;
      }

      if (DXGetObjectClass((Object)array) != CLASS_ARRAY)
      {
        DXSetError(ERROR_BAD_CLASS, "data component of \"lattice_vectors\" should be an array");
        goto error;
      }
    }


    if (DXGetObjectClass(in[2]) != CLASS_STRING)    {
       DXGetArrayInfo(array, &in_knt[2], &type, &category, &rank, &shape);
       if (type != TYPE_FLOAT || category != CATEGORY_REAL ||
             !((rank == 0) || ((rank == 1)&&(shape == 3))))
       {
	 if(type != TYPE_FLOAT)
	   sprintf(mstring,"Lattice vectors must be of type FLOAT!");
	 if(category != CATEGORY_REAL)
	   sprintf(mstring,"Lattice vectors must be of category REAL!");
	 if(!((rank == 0) || ((rank == 1)&&(shape == 3))))
	   sprintf(mstring,"Incorrect rank=%d or shape=%d!",rank,shape);

	 DXMessage(mstring);

         DXSetError(ERROR_INVALID_DATA, "input \"lattice_vectors\"");
         goto error;
       }

       in_data[2] = DXGetArrayData(array);
       if (! in_data[2])
          goto error;

    }
  }
  
  /* ==================== DO THE OUTPUT ================================*/

  /* BERND
   *             here comes the real work horse code */

  /* indicate change of the positions component 
   * this automatically removes the data field ! */

  DXChangedComponentStructure((Field)out[0],"positions");
   

  lvec = (float *) in_data[2];  /* get pointer to the lattice vectors */

  irep[0] = (int) *in_data[1];  /* get replication vector */
  irep[1] = (int) *(in_data[1]+1);
  irep[2] = (int) *(in_data[1]+2);
  if(irep[0]<=0) irep[0]=1; if(irep[1]<=0)irep[1]=1; if(irep[2]<=0) irep[2]=1;


  /*
   * Create an output data array typed according to the
   * specification given
   */
  array = DXNewArray(TYPE_FLOAT, CATEGORY_REAL, drank, dshape);
  if (! array)
    goto error;

  /*
   * Set the dependency of the array to the same as the first input
   */
  if (src_dependency_attr != NULL)
    if (! DXSetAttribute((Object)array, "dep", src_dependency_attr))
      goto error;

  /* BERND
   * create output data field big enough for everything
   */
  out_knt[0] = in_knt[0]*irep[0]*irep[1]*irep[2];
  

  /*
   * Actually allocate the array data space
   */
  if (! DXAddArrayData(array, 0, out_knt[0], NULL))
    goto error;

  /*
   * If the output vector slot is not NULL, then it better be a field, and
   * we'll add the new array to it as its data component (delete any prior
   * data component so that its attributes won't overwrite the new component's)
   * Otherwise, place the new array into the out vector.
   */
  if (out[0])
  {
    if (DXGetObjectClass(out[0]) != CLASS_FIELD)
    {
      DXSetError(ERROR_INTERNAL, "non-field object found in output vector");
      goto error;
    }

    if (DXGetComponentValue((Field)out[0], "data"))
      DXDeleteComponent((Field)out[0], "data");

    if (! DXSetComponentValue((Field)out[0], "data", (Object)array))
      goto error;

  }
  else
    out[0] = (Object)array;
  /*
   * Now get the pointer to the contents of the array
   */
  out_data[0] = DXGetArrayData(array);
  if (! out_data[0])
    goto error;

  sprintf(mstring,"Allocated space for new data array...");
  DXMessage(mstring);


  /* 
   * BERND: allocate space for the new position array 
   */
  if(pclass == CLASS_ARRAY) {
    outpos= DXNewArray(TYPE_FLOAT, CATEGORY_REAL, 1,3);
    if(!outpos) goto error;
    if(!DXAddArrayData(outpos,0,irep[0]*irep[1]*irep[2]*p_knt, NULL))
      goto error;
    outpospoi=(Point *)DXGetArrayData(outpos);
  }
  else { /* regular array. Just need to adjust sizes */
    DXQueryGridPositions(parray,&nterms, orcounts, rorigin, rdeltas);
    if(nterms !=3) {
      DXSetError(ERROR_INVALID_DATA, "DATA MUST HAVE 3D GRID POSITIONS");
      goto error;}
    for(j=0;j<3;j++) rcounts[j]=orcounts[j]*irep[j];
    nparray = DXMakeGridPositionsV(nterms, rcounts, rorigin, rdeltas);
  }
  /* 
   * BERND: create new gridconnections array if necessary
   */
  if(carray) {
    DXQueryGridConnections(carray, &nterms, rcounts);
    if(nterms !=3) {
      DXSetError(ERROR_INVALID_DATA, "DATA MUST HAVE 3D GRID CONNECTIONS");
      goto error;}
    for(j=0;j<3;j++) rcounts[j]=rcounts[j]*irep[j];
    ncarray=DXMakeGridConnectionsV(nterms,rcounts);
  }
  


  /* 
   * BERND: replicate the data and position arrays
   * according to the irep[] array 
   */

  outdatapoi = (float *) out_data[0];
  ldain = in_knt[0]; /* leading dimension of input array */

  if(drank==0) dshape=1; 


  if((irep[0]!=1)||(irep[1]!=1)||(irep[2]!=1)) {
    sprintf(mstring,"Replicating: %d %d %d", irep[0], irep[1], irep[2]);
    DXMessage(mstring);
    sprintf(mstring,"ldain= %d, dshape=%d", ldain, dshape);
    DXMessage(mstring);



    if(lvec==NULL) {
      DXSetError(ERROR_INVALID_DATA, "NEED LATTICE VECTOR INPUT!");
      goto error;
    }
    if(pclass == CLASS_ARRAY) { /* irregular positions */
      /* translate positions */
      for(i=0;i<irep[0];i++)
	for(j=0;j<irep[1];j++)
	  for(k=0;k<irep[2];k++)
	    for(l=0;l<ldain;l++) {
	      /* first do position */
	      for(ic=0;ic<3;ic++)
		npos[ic]=*(p_positions+3*l+ic)+ (float)i * lvec[ic]+
		  (float)j * lvec[3+ic] + (float)k * lvec[6+ic];
	      outpospoi[(i*irep[1]*irep[2]+j*irep[2]+k)*ldain+l] = 
		DXPt(npos[0], npos[1], npos[2]); 
	      /* then do data */
	      for(ic=0;ic<dshape;ic++)
	       outdatapoi[((i*irep[1]*irep[2]+j*irep[2]+k)*ldain+l)*dshape+ic]=
		 *((float *)(in_data[0]+l*dshape+ic));
	    }
    } else { 
      /* regular positions: different data replication scheme 
       *  z varies fastest!
       */
      ldz=orcounts[2];      ldy=orcounts[1];      ldx=orcounts[0];
      sprintf(mstring,"ldx=%d, ldy=%d, ldz=%d", ldx, ldy, ldz);
      DXMessage(mstring);

      for(kx=0;kx<irep[0];kx++)
	for(lx=0;lx<ldx;lx++) 
	  for(ky=0;ky<irep[1];ky++) 
	    for(ly=0;ly<ldy;ly++) 
	      for(kz=0;kz<irep[2];kz++)
		for(lz=0;lz<ldz;lz++){
		  for(ic=0;ic<dshape;ic++)
		    outdatapoi[(kx*ldx*irep[1]*ldy*irep[2]*ldz +
				lx*irep[1]*ldy*irep[2]*ldz +
				ky*ldy*irep[2]*ldz + 
				ly*irep[2]*ldz + 
				kz*ldz+
				lz)      *dshape+ic]=
		      *((float *)(in_data[0]+((lx*ldy+ly)*ldz+lz)*dshape+ic));
		}
    }


    
    sprintf(mstring,"Replicated: %d %d %d", irep[0], irep[1], irep[2]);
    DXMessage(mstring);
  }
  else {                    /* just copy positions over */
    sprintf(mstring,"Copying data: %d %d", ldain, dshape);
    DXMessage(mstring);

    for(l=0;l<ldain;l++) {
      /* first do position */
      if(pclass == CLASS_ARRAY) {
	for(ic=0;ic<3;ic++)
	  npos[ic]=*(p_positions+3*l+ic);
	outpospoi[l] = DXPt(npos[0], npos[1], npos[2]); 
      }
      /* then do data */
      for(ic=0;ic<dshape;ic++)
	outdatapoi[l*dshape+ic]=*((float*)(in_data[0]+l*dshape+ic));
      
    }
    sprintf(mstring,"Copied data");
    DXMessage(mstring);

  }


  /* BERND 
   */

  /* place the new positions into the output field */


  if (DXGetComponentValue((Field)out[0], "positions"))
    DXDeleteComponent((Field)out[0], "positions");

  if(pclass == CLASS_ARRAY) {
    DXSetComponentValue((Field)out[0],"positions",(Object) outpos);
    outpos=NULL; } 
  else {
    DXSetComponentValue((Field)out[0],"positions",(Object) nparray);
  }

  if (DXGetComponentValue((Field)out[0], "connections"))
    DXDeleteComponent((Field)out[0], "connections");

  if(carray) 
    DXSetComponentValue((Field)out[0],"connections",(Object) ncarray);


  /* finalize the field */
  DXEndField((Field)out[0]); 

  result=1;


  /*
   * In either event, clean up allocated memory
   */

error:
  return result;
}

int
ReplicateCell_worker(
    int p_knt, int p_dim, float *p_positions,
    int udata_field_knt, float *udata_field_data,
    int replication_dim_knt, float *replication_dim_data,
    int lattice_vectors_knt, float *lattice_vectors_data,
    int replicated_field_knt, float *replicated_field_data)
{
  /*
   * The arguments to this routine are:
   *
   *  p_knt:           total count of input positions
   *  p_dim:           dimensionality of input positions
   *  p_positions:     pointer to positions list
   *
   * The following are inputs and therefore are read-only.  The default
   * values are given and should be used if the knt is 0.
   *
   * udata_field_knt, udata_field_data:  count and pointer for input "udata_field"
   *                   no default value given.
   * replication_dim_knt, replication_dim_data:  count and pointer for input "replication_dim"
   *                   non-descriptive default value is ""0 0 0""
   * lattice_vectors_knt, lattice_vectors_data:  count and pointer for input "lattice_vectors"
   *                   no default value given.
   *
   *  The output data buffer(s) are writable.
   *  The output buffer(s) are preallocated based on
   *     the dependency (positions or connections),
   *     the size of the corresponding positions or
   *     connections component in the first input, and
   *     the data type.
   *
   * replicated_field_knt, replicated_field_data:  count and pointer for output "replicated_field"
   */

  /*
   * User's code goes here
   */
     
     
  /*
   * successful completion
   */
   return 1;
     
  /*
   * unsuccessful completion
   */
error:
   return 0;
  
}
